console.log('Hello!');
console.log(123);
console.log(true);
var salut = "Hello";
console.log(salut);
console.log([13, 44, 44, 12]);
console.log({nume: 'Ion', prenume:'Vasile'});
console.table({nume: 'Ion', prenume:'Vasile'});
console.table([13, 44, 44, 12]);

console.error("Ceva nu e bine");
console.clear();

console.time('mytimer');
    console.log('Hello!');
    console.log(123);
    console.log(true);
    var salut = "Hello";
    console.log(salut);
    console.log([13, 44, 44, 12]);
    console.log({nume: 'Ion', prenume:'Vasile'});
    console.table({nume: 'Ion', prenume:'Vasile'});
console.timeEnd('mytimer');
console.error("Cevanuebine");

