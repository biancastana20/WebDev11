// console.log("salut");

var zi = "Marti";

switch(zi){
  case 'Luni':
    console.log('Mergem la sala');
    break;
  case 'Marti':
    console.log('Mergem la cumparaturi');
  case 'Miercuri':
  case 'Vineri':
    console.log('Mancam sanatos');
  default:
    console.log('Ne odihnim');
    break;
}


// if(zi === 'Luni'){
//   console.log('Mergem la sala');
// }
// else if (zi === 'Marti'){
//   console.log('Mergem la cumparaturi');
//   console.log('Mancam sanatos');
//   console.log('Ne odihnim');
// }
// else if( zi === 'Miercuri' || 'Vineri'){
//   console.log('Mancam sanatos');
//   console.log('Ne odihnim');
// }
// else{
//   console.log('Ne odihnim');
// }
