// Math object attributes
val = Math.PI;
val = Math.E;

// Math methods
val = Math.round(2.50);//3
val = Math.ceil(2.1);//3
val = Math.floor(2.8);//2

val = Math.sqrt(64);//8
val = Math.min(44, 3, 33, 44);
val = Math.max(44, 3, 33, 445);

val = Math.ceil(Math.random() * 6);
// Workshop 2 - Simulate a dice

// output
console.log(val); 