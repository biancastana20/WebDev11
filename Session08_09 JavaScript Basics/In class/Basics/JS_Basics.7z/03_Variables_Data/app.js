// undefined variable
var name = 'Popescu Ion';//string
var n = 2;//number
var isRaining = true;//boolean
var listOfNumbers = [1, 44, 411, 11, 444];//arrays

// Multi word variables
var firstName = 'Ion'; // Camel Case
var first_name = 'Ion' // Underscore - used in C/C++
var FirstName = 'Ion'; // not for var



