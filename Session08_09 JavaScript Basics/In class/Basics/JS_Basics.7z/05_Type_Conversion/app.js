// number/boolean to string
var val;
val = String(4+4);
val = true;
val = String(true);

//string/boolean to number
val = '222';
val = Number('222');
val = true;
val = Number(true);//1
val = Number(false);//0

// output
var balance = 1200;
var name = "Costel";

// Workshop: 
console.log(name + ", contul tau are balanta de " + balance + " lei.");
// "Costel, contul tau are balanta de 1200 lei."

console.log(typeof val);
console.log("Alin" + " Costin");


