// console.log("loops");

// WHILE LOOP
// var n = 10;
// var i = 0;
// while(i <= n) {
//   console.log(i);
//   i++;
// }

// DO WHILE LOOP
// var n = 10;
// var i = 0;
// do{
//   console.log(i);
//   i++;
// }while(i <= n)

// FOR
var n = 10;
for(var i = 0; i <= n; i++){
  console.log(i);
}
